

	
	
//radials	={};



		
function openRadial(id,type){

	//startingIndex	=	2;

if(type	==	"full"){startingIndex=0;}
else if(type	==	"left"){startingIndex=0;}
else if(type	==	"top"){startingIndex=2;}
else if(type	==	"right"){startingIndex=4;}
else if(type	==	"bottom"){startingIndex=6;}


if(radials[id].length<9){
	
	
	//Button Margin Change Based On container
	
	parentTop	=	parseInt($("#"+id).parent().css("margin-top"));
	parentLeft	=	parseInt($("#"+id).parent().css("margin-left"));
	
	


	//Orientation margin
	if(type	==	"full"	){
	
		if(parentLeft<80	&&	$("#"+id).parent().find(" .radial-inner").length	==	0	){
		
			$("#"+id).parent().css({ 'margin-left': '80px' });
		
		}
		else if(parentLeft>=80){
	
			$("#"+id).parent().css({ 'margin-left': '0px' });
	
		}
		
		if($("#"+id).parent().offset().top<80	&&	$("#"+id).parent().find(" .radial-inner").length	==	0	){
		
			$("#"+id).parent().css({ 'margin-top': '80px' });
		
		}
		else {$("#"+id).parent().css({ 'margin-top': '0px' });}
		
	}
	
	if(type	==	"top"	||	type	==	"bottom"){	
	
	
		if($("#"+id).parent().offset().left<80	&&	$("#"+id).parent().find(" .radial-inner").length	==	0	){
		
			$("#"+id).parent().css({ 'margin-left': '80px' });
		
		}
		
		else if(($(window).width()	-	$("#"+id).parent().offset().left)<80){
			$("#"+id).parent().css({ 'right': 80});	
		}
		
		else {
	
			$("#"+id).parent().css({ 'right':0});	
	
		}	
	
	
	
	
	}
	
	
	
	
	
	

	
	
	
	
	//Build Menu
	
	if($("#"+id).parent().find(" .radial-inner").length>0){
		
				
		for(i=0;i<radials[id].length;i++){
			
			$("#"+id).parent().find(" .radial-inner").eq(i).hide((500*(i))/4);
			
		
		}
		setTimeout(function() {			$("#"+id).parent().find(" .radial-inner").remove();		}, 500);		
		
		$("#"+id).parent().find(".radialList").remove();//Remove Radial List
		
		}
	else{	
	
	for(i=0;i<radials[id].length;i++){
	
		
		
		
		marginTop	=	"margin-top:0px;";
		marginLeft	=	"margin-left:0px;";
		
		if(i+startingIndex	==	0	||	i+startingIndex	==	8){
			
			marginTop	=	"margin-top:-75px;";
			marginLeft	=	"margin-left:5px;";			
			
			
		}
	
		if(i+startingIndex	==	1	||	i+startingIndex	==	9){
			
			marginTop	=	"margin-top:-55px;";
			marginLeft	=	"margin-left:60px;";			
			
			
		}

		if(i+startingIndex	==	2	||	i+startingIndex	==	10){
			
			marginTop	=	"margin-top:0px;";
			marginLeft	=	"margin-left:85px;";			
			
			
		}
		
		if(i+startingIndex	==	3){
			
			marginTop	=	"margin-top:60px;";
			marginLeft	=	"margin-left:65px;";			
			
			
		}
		if(i+startingIndex	==	4){
			
			marginTop	=	"margin-top:85px;";
			marginLeft	=	"margin-left:5px;";			
			
			
		}
		if(i+startingIndex	==	5){
			
			marginTop	=	"margin-top:55px;";
			marginLeft	=	"margin-left:-50px;";			
			
			
		}	
		if(i+startingIndex	==	6){
			
			marginTop	=	"margin-top:0px;";
			marginLeft	=	"margin-left:-70px;";			
			
			
		}		
		
		if(i+startingIndex	==	7){
			
			marginTop	=	"margin-top:-55px;";
			marginLeft	=	"margin-left:-50px;";			
			
			
		}		



		
		
	//	console.log(radials[id][i]);
		if(typeof radials[id][i].submenu =="object"){	prefix	=	"subMenu";}
		else{	prefix	=	"";}
		
		$("#"+id).parent().append(
		
		'<div class=" '	+	prefix	+	' btn btn-'	+	radials[id][i].btn+	' radial-inner  text-center myPopover" data-toggle="popover" data-content="'+radials[id][i].title+'" style="'	+	marginTop	+	marginLeft	+	'"> '+
	
		'<i class=" fa '	+	radials[id][i].icon	+	' text-light" ></i>'+
		'</div>'
		
		);
		
		$("#"+id).parent().find(" .radial-inner").eq(i).show((500*(i))/4);
	}
	
	
	
	  $('.myPopover').popover({
    container: 'body',trigger:"hover"
  })
	}		
	}
	
	else{console.log("Number of max elements are 8");}
	
}




function initRadial(){
	$(".radial-container").remove();
	counter	=	0;
	
	$.each(radials,function(key,val){
	
	
	//display:none;
		$(val.target).prepend(
		'<div class="radial-container " style="display:none;">'+
			'<div style="font-size:23px;" class="btn btn-'	+	val.color	+	' radial text-center" id="'	+	key	+	'" radialPosition="'	+	val.type	+	'"> '+
				'<i class="fa fa-bars text-light   center" ></i>'+
			'</div>'+
		'</div>')
			
		
		$(".radial-container").eq(counter).fadeIn(  500*counter );
		console.log(counter);
		counter++;
	});
	
	
	
	$("body").on("click",".radial ",function(){
				
		openRadial($(this).attr("id"),$(this).attr("radialPosition"));console.log("row 181");
	
		counter++;
		
	})
	








	//Menu Click
	$("body").on("click",".radial-container .radial-inner",function(){
	
	
	
		index	=	$(this).parent().find(".radial-inner").index($(this));
		id		=	$(this).parent().find(".radial").attr("id");
		type	=	$(this).parent().find(".radial").attr("radialposition");
	
	
	
		if(	$(this).hasClass("subMenu")==true){
		
		
	

			$(this).parent().find(".radialList").remove();
		
		
		
		
		if(type	==	"top"){	margins	=	"margin-left:-110px;margin-top:145px;";}
		else if(type	==	"full"	){	margins	=	"margin-left:140px;margin-top:-30px;";}
		else if(type	==	"right"){	margins	=	"margin-left:-380px;margin-top:-30px;";}
		else if(type	==	"bottom"){	margins	=	"margin-left:140px;margin-top:-180px;";}
		else if(type	==	"left"){	margins	=	"margin-left:140px;margin-top:-120px;";}
		else{margins="";}
		
		
		//alert(type	+	" "+margins);
		
		

		$(this).parent().append("<div class=' radialList position-absolute' style='width:300px;"	+	margins	+	"'></div>");
		
		
	
	
			$.each(radials[id][index].submenu,function(key,val){
	
				$("#"+id).parent().find(".radialList").append("<div class='submenu-content w-100 btn btn-"	+	val.btn	+	" text-light p-2 border-bottom '><i class='fa "	+	val.icon	+	"'></i> "	+	val.title+	"</div>");
	
			})
	
		}
		
		else{
		
			openLink(radials[id][index].src);
			
			$(this).parent().find(".radialList").remove();
		
		}
	
	})

	









	//SubMenu Click
	$("body").on("click",".radial-container .submenu-content",function(){
		
	submenuIndex	=	$(this).parent().parent().find(".submenu-content").index($(this));
	
	openLink(radials[id][index].submenu[submenuIndex].src);
	
	})




}




function	openLink(src){
	
	console.log("LINK: "+ src);
	
}




/*
initRadial(); //for start

*/




